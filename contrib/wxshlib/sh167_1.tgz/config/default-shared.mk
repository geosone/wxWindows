#
# Makefile for the WX default shared library stub
#

# no rules.

